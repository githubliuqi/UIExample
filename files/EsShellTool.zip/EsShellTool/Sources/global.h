#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#include "GlobalDefine.h"
#include "Enc/EsEnc.h"
#include "Dec/EsDec.h"
#include "Verify/EsVerify.h"

#ifndef LOG_TAG   
#define LOG_TAG    "TestEncDec"
#endif 
#ifdef _DEBUG
#define _DEBUG_LOG_ON_  // SlotAPI-M�ӿڵ�����־��ӡ���أ������򿪣�ע�͵���ر�
#endif
#if defined _DEBUG_LOG_ON_  
#if defined _OS_ANDROID_
#pragma message("LOG ON macro _OS_ANDROID_ defined ")
#include <android/log.h>  
#define LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)   
#define LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)   
#define LOGW(...)  __android_log_print(ANDROID_LOG_WARN,LOG_TAG,__VA_ARGS__)   
#define LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)   
#define LOGF(...)  __android_log_print(ANDROID_LOG_FATAL,LOG_TAG,__VA_ARGS__)
#define LOGBYTEARRAY LogByteArray
#elif defined _OS_WINDOWS_
#pragma message("LOG ON macro _OS_WINDOWS_ defined ")
#include <stdarg.h>
#include <windows.h>
//         #define LOGD(...) _OutputDebugStr_Fmt(__VA_ARGS__)  // ������������������
//         #define LOGI(...) _OutputDebugStr_Fmt(__VA_ARGS__)   
//         #define LOGW(...) _OutputDebugStr_Fmt(__VA_ARGS__)
//         #define LOGE(...) _OutputDebugStr_Fmt(__VA_ARGS__)
//         #define LOGF(...) _OutputDebugStr_Fmt(__VA_ARGS__)

#include <stdio.h>
#define LOGD(...) fprintf(stdout, __VA_ARGS__); fprintf(stdout, "\n");  // ������ն�
#define LOGI(...) fprintf(stdout, __VA_ARGS__); fprintf(stdout, "\n");
#define LOGW(...) fprintf(stdout, __VA_ARGS__); fprintf(stdout, "\n");
#define LOGE(...) fprintf(stdout, __VA_ARGS__); fprintf(stdout, "\n");
#define LOGF(...) fprintf(stdout, __VA_ARGS__); fprintf(stdout, "\n");
#define LOGBYTEARRAY LogByteArray
#else
#pragma message("IOS")
#include <stdio.h>
#define LOGD(...) printf("\n");printf(__VA_ARGS__);printf("  ~\n")
#define LOGI(...) printf("\n");printf(__VA_ARGS__);printf("  ~\n")
#define LOGW(...) printf("\n");printf(__VA_ARGS__);printf("  ~\n")
#define LOGE(...) printf("\n");printf(__VA_ARGS__);printf("  ~\n")
#define LOGF(...) printf("\n");printf(__VA_ARGS__);printf("  ~\n")
#define LOGBYTEARRAY(tag,data,len) if(data){ for(int __i = 0; __i < len; __i++){printf("%02X",data[__i]);}printf("\n");}do{}while(0)
#endif
#else
#pragma message("LOG OFF")
#define LOGD(...)
#define LOGI(...)
#define LOGW(...)
#define LOGE(...)
#define LOGF(...) 
#define LOGBYTEARRAY LogByteArray
#endif

#if defined(__cplusplus)
extern "C" {
#endif

	u4 CALL_TYPE Initialize();
	u4 CALL_TYPE Finalize();

	u4 CALL_TYPE LogByteArray(const char* szTag, const void* pvHex, u4 u4HexLen);

#if defined(__cplusplus)
}
#endif

#endif