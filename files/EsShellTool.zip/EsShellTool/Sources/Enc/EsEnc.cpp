#ifdef _OS_WINDOWS_
#include <windows.h>
#include <tchar.h>
#endif
#include "EsEnc.h"
#include <openssl/ossl_typ.h>
#include <openssl/evp.h>

static u1 gs_pbKey[] = {0x37,0x6A,0x64,0x6B,0x61,0x66,0x76,0x51,0x34,0x2D,0x57,0x45,
					    0x2E,0x2F,0x31,0x47,0x48,0x70,0x3D,0x41,0x64,0x67,0x78,0x67};

u4 EsEncInner(const u1* pbKey, const u1* pu1Data, u4 u4DataLen, u1* pu1EncData, u4* pu4EncDataLen)
{
	u4	u4Result = ERROR_NO_ERROR;
	u1*	pu1DataTmp = NULL;
	u4	u4DataTmpLen;
	EVP_CIPHER_CTX ctx;
	u1 iv[0x08] = {0};

	if (NULL == pu1Data || 0x00 == u4DataLen || NULL == pu1EncData || NULL == pu4EncDataLen)
	{
		u4Result = ERROR_COMMON_INVALID_PARAM;
		goto END;
	}

	u4DataTmpLen = u4DataLen + 0x10;
	u4Result = EsMemAlloc((void**)&pu1DataTmp, NULL, u4DataTmpLen);
	IF_ERROR_GOTO_END();

	EsPadding(pu1Data, u4DataLen, PADDING_TYPE_PKCS_5, 0x08, pu1DataTmp, &u4DataTmpLen);

	
	EVP_EncryptInit(&ctx, EVP_des_ede_cbc(), pbKey, iv);

	EVP_EncryptUpdate(&ctx, pu1EncData, (int*)pu4EncDataLen, pu1DataTmp, u4DataTmpLen);
END:
	if (NULL != pu1DataTmp)
	{
		EsMemSafeClear(pu1DataTmp, u4DataTmpLen);
		EsMemFree((void**)&pu1DataTmp);
	}
	return u4Result;
}

u4 CALL_TYPE EsEnc(const u1* pu1Data, u4 u4DataLen, u1* pu1EncData, u4* pu4EncDataLen)
{
	return EsEncInner(gs_pbKey, pu1Data, u4DataLen, pu1EncData, pu4EncDataLen);
}