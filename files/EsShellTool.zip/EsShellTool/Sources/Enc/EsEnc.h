#ifndef _Es_ENC_H_
#define _Es_ENC_H_

#include "../GlobalDefine.h"

#if defined(__cplusplus)
extern "C" {
#endif

	u4 CALL_TYPE EsEnc(const u1* pu1Data, u4 u4DataLen, u1* pu1EncData, u4* pu4EncDataLen);
	u4 EsEncInner(const u1* pbKey, const u1* pu1Data, u4 u4DataLen, u1* pu1EncData, u4* pu4EncDataLen);

#if defined(__cplusplus)
};
#endif

#endif