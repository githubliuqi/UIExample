#ifdef _OS_WINDOWS_
#include <windows.h>
#include <tchar.h>
#endif
#include "EsDec.h"
#include <openssl/ossl_typ.h>
#include <openssl/evp.h>

// static u1 gs_pbKey[] = {0x37,0x6A,0x64,0x6B,0x61,0x66,0x76,0x51,0x34,0x2D,0x57,0x45,
// 0x2E,0x2F,0x31,0x47,0x48,0x70,0x3D,0x41,0x64,0x67,0x78,0x67};

static u1 gs_pu1ProtectionKey[] = {0xa3,0x84,0xb2,0x2c,0xda,0x78,0x2f,0x3a,0x6e,0xab,0x57,0xd8,0x3c,0x71,0xed,0xfa};
static u1 gs_pu1EncKey[] ={0x77,0x63,0xfa,0xf1,0xc5,0xe5,0x25,0x1f,0xb3,0x2f,0x14,0x39,0x18,0x52,0xc5,0x4b,
0x76,0x05,0x07,0x8b,0x15,0x43,0xc2,0xb0,0x02,0x9e,0xb6,0x8f,0x02,0x4b,0xd4,0xc6};

u4 EsDecInner(const u1* pu1Key, const u1* pu1EncData, u4 u4EncDataLen, u1* pu1Data, u4* pu4DataLen)
{
	u4	u4Result = ERROR_NO_ERROR;
	u1*	pu1DataTmp = NULL;
	u4	u4DataTmpLen;
	EVP_CIPHER_CTX ctx;
	u1 iv[0x08] = {0};

	if (NULL == pu1EncData || 0x00 == u4EncDataLen || NULL == pu1Data || NULL == pu4DataLen)
	{
		u4Result = ERROR_COMMON_INVALID_PARAM;
		goto END;
	}

	u4DataTmpLen = u4EncDataLen + 0x10;
	u4Result = EsMemAlloc((void**)&pu1DataTmp, NULL, u4DataTmpLen);
	IF_ERROR_GOTO_END();

	EVP_DecryptInit(&ctx, EVP_des_ede_cbc(), pu1Key, iv);
	EVP_DecryptUpdate(&ctx, pu1Data, (int*)&u4DataTmpLen, pu1EncData, u4EncDataLen);
	*pu4DataLen = u4DataTmpLen;

	EVP_DecryptFinal(&ctx, pu1Data + u4DataTmpLen, (int*)&u4DataTmpLen);
	*pu4DataLen += u4DataTmpLen;

END:
	if (NULL != pu1DataTmp)
	{
		EsMemSafeClear(pu1DataTmp, u4DataTmpLen);
		EsMemFree((void**)&pu1DataTmp);
	}
	return u4Result;
}

u4 CALL_TYPE EsDec(const u1* pu1EncData, u4 u4EncDataLen, u1* pu1Data, u4* pu4DataLen)
{
	u4	u4Result = ERROR_NO_ERROR;
	u1* pu1Key = NULL;
	u4	u4KeyLen;

	if (NULL == pu1EncData || 0x00 == u4EncDataLen || NULL == pu1Data || NULL == pu4DataLen)
	{
		u4Result = ERROR_COMMON_INVALID_PARAM;
		goto END;
	}

	u4KeyLen = 0x40;
	u4Result = EsMemAlloc((void**)&pu1Key, NULL, u4KeyLen);
	IF_ERROR_GOTO_END();

	u4Result = EsDecInner(gs_pu1ProtectionKey, gs_pu1EncKey, sizeof(gs_pu1EncKey), pu1Key, &u4KeyLen);
	IF_ERROR_GOTO_END();

	u4Result = EsDecInner(pu1Key, pu1EncData, u4EncDataLen, pu1Data, pu4DataLen);
	IF_ERROR_GOTO_END();

END:
	if (NULL != pu1Key)
	{
		EsMemSafeClear(pu1Key, u4KeyLen);
		EsMemFree((void**)&pu1Key);
	}
	return u4Result;
}