#ifndef _ES_DEC_H_
#define _ES_DEC_H_
#include "../GlobalDefine.h"

#if defined(__cplusplus)
extern "C" {
#endif

	u4 CALL_TYPE EsDec(const u1* pu1EncData, u4 u4EncDataLen, u1* pu1Data, u4* pu4DataLen);
	u4 EsDecInner(const u1* pu1Key, const u1* pu1EncData, u4 u4EncDataLen, u1* pu1Data, u4* pu4DataLen);

#if defined(__cplusplus)
};
#endif

#endif