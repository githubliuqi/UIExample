#ifndef _GLOBAL_DEFINE_H_
#define _GLOBAL_DEFINE_H_

#include <EsTypeDef.h>
#include <EsError.h>
#include <Escommon/Escommon.h>


#endif