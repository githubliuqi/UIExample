#ifndef _ES_VERIFY_H_
#define _ES_VERIFY_H_

#include "../GlobalDefine.h"

#if defined(__cplusplus)
extern "C" {
#endif

	u4 CALL_TYPE EsVerifyCert(const void* pvCert, u4 u4CertLen);

#if defined(__cplusplus)
}
#endif

#endif