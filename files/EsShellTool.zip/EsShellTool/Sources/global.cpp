#ifdef _OS_WINDOWS_
#include <windows.h>
#include <tchar.h>
#endif
#include "global.h"

ESBOOL gs_bInitialized = ESFALSE;

u4 CALL_TYPE Initialize()
{
	u4 u4Result = ERROR_NO_ERROR;

	if (ESFALSE == gs_bInitialized)
	{
		u4Result = EsCommonLibInit();
		gs_bInitialized = ESTRUE;
	}

	return u4Result;
}

u4 CALL_TYPE Finalize()
{
	u4 u4Result = ERROR_NO_ERROR;
	if (ESTRUE == gs_bInitialized)
	{
		u4Result = EsCommonLibRelease();
		gs_bInitialized = ESFALSE;
	}
	return u4Result;
}

u4 CALL_TYPE LogByteArray(const char* szTag, const void* pvHex, u4 u4HexLen)
{
#ifdef _DEBUG
// 	if(NULL != pvHex && 0x00 != u4HexLen)
// 	{
// 		u4 u4MaxLen = 0x100;
// 		u4	u4Len;
// 		char* szAsc = (char*)malloc(2*(u4MaxLen+0x01));
// 		u1*	pu1Pos = (u1*)pvHex;
// 		if (NULL != szAsc)
// 		{
// 			LOGI("LogByteArray szTag=%s value=", szTag);
// 			while (u4HexLen > 0x00)
// 			{
// 				u4Len = u4MaxLen > u4HexLen ? u4HexLen : u4MaxLen;
// 				EsHex2Asc(pu1Pos, u4Len, szAsc);
// 				LOGI("%s", szAsc);
// 				pu1Pos += u4Len;
// 				u4HexLen -= u4Len;
// 			}
// 			free(szAsc);
// 
// 			return 0;
// 		}
// 	}
// 	return -1;
	if(NULL != pvHex && 0x00 != u4HexLen)
	{
		u4 u4MaxLen = 0x100;
		u4	u4Len ,i;
		char* szAsc = (char*)malloc(u4MaxLen);
		u1*	pu1Pos = (u1*)pvHex;
		if (NULL != szAsc)
		{
			LOGI("LogByteArray szTag=%s value=", szTag);
			i = 0x00;
			for (i = 0x00; i < u4HexLen; i++)
			{
				sprintf_s(szAsc, u4MaxLen, "0x%02X,",(u1)pu1Pos[i]);
				printf(szAsc);
			}
			printf("\n");
			free(szAsc);

			return 0;
		}
	}
	return -1;

#endif
}