// TestEncDec.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include <EsTypeDef.h>
#include <EsError.h>
#include <Escommon/Escommon.h>

#include "../../../Sources/Dec/EsDec.h"
#include "../../../Sources/Enc/EsEnc.h"
#define MAX_DATA_LEN 0x400
int _tmain(int argc, _TCHAR* argv[])
{
	u4		u4Result;
	u1*		pu1DataSrc = NULL;
	u4		u4DataSrcLen;
	u1*		pu1EncData = NULL;
	u4		u4EncDataLen;
	u1*		pu1Data = NULL;
	u4		u4DataLen;

// 	u4DataSrcLen = 0x14;
// 	EsGetRand(pu1DataSrc, u4DataSrcLen);

//	u4DataSrcLen = 6205304;
	u4DataSrcLen = 0x24;
	u4Result = EsMemAlloc((void**)&pu1DataSrc, NULL, u4DataSrcLen);
	IF_ERROR_GOTO_END();
	memset(pu1DataSrc, 0x31, u4DataSrcLen);
	
	u4EncDataLen = u4DataSrcLen+0x10;
	u4Result = EsMemAlloc((void**)&pu1EncData, NULL, u4EncDataLen);
	IF_ERROR_GOTO_END();
	u4Result = EsEnc(pu1DataSrc, u4DataSrcLen, pu1EncData, &u4EncDataLen);
	IF_ERROR_GOTO_END();

	u4DataLen =  u4DataSrcLen+0x10;
	u4Result = EsMemAlloc((void**)&pu1Data, NULL, u4DataLen);
	IF_ERROR_GOTO_END();
	u4Result = EsDec(pu1EncData, u4EncDataLen, pu1Data, &u4DataLen);
	IF_ERROR_GOTO_END();

	if (u4DataLen != u4DataSrcLen
		|| 0x00 != memcmp(pu1DataSrc, pu1Data, u4DataSrcLen))
	{
		u4Result = ERROR_COMMON_INVALID_DATA;
	}
END:
	if (NULL != pu1DataSrc)
	{
		EsMemFree((void**)&pu1DataSrc);
	}
	if (NULL != pu1EncData)
	{
		EsMemFree((void**)&pu1EncData);
	}
	if (NULL != pu1Data)
	{
		EsMemFree((void**)&pu1Data);
	}
	return u4Result;
}

