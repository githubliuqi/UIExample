//
//  main.cpp
//  SHA
//
//  Created by esdev2 on 16/10/30.
//  Copyright © 2016年 esdev2. All rights reserved.
//

#include <iostream>
#include "EsAlgorithm.h"
#include "EsCommon.h"


char *g_dictWords = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_";

//单词替换
char *zmWordsReplace(char *src, char *oldstr, char *newstr);
//字符串替换
char *zmStringReplace(char *src, char *oldstr, char *newstr);



int main(int argc, const char * argv[]) {
    
//    printf("argc  = %d\n",argc);
//    
//    for (int i = 0 ; i< argc ; i++)
//    {
//        printf("argv[%d] = %s\n",i,argv[i]);
//    }
    
   
   
    u1 pvHashValue[0x20];//256bit(32byte)
    u1 pvHexHashValue[0x40];
    
    if (argc == 2)
    {  // 计算SHA256 哈希值
        const char *msg = argv[1];
        //printf("%s \n",msg);
        EsCommonLibInit();
        EsHashData(ES_HASH_ALG_SHA256, msg, (int)strlen(msg) , pvHashValue);
        //printf("%s",pvHashValue);
        EsHex2Asc((const void*)pvHashValue, 0x20, (char*)pvHexHashValue);
        EsCommonLibRelease();
        printf("%s\n",pvHexHashValue);
    }else if (argc == 4)
    {
        //printf("单词替换--------");
        char *rawString = (char *)argv[1];
        char *oldstr = (char *)argv[2];
        char *newstr = (char *)argv[3];
        
        //单词替换
        char *newString = zmWordsReplace(rawString, oldstr, newstr);
        char *retString = newString;
        
        printf("%s\n", retString);
        if (rawString != retString) {
            free(retString);
        }

    }else
    {
        printf("ERROR");
    }
    
    return 0;
}

//单词替换，如:This is a good news.==>is -> are ==> This are a good news.
char *zmWordsReplace(char *src, char *oldstr, char *newstr)
{
    int iReplaceCount = 0;
    //char *olds = src;
    char pre = '\0';
    char aft = '\0';
    char *pFindChar = NULL;
    char *pStart = src;
    
    char *newString = src;
    char *newStringTmp = NULL;
    //step :首先统计要替换的单词数量
    char *pFindWord = strstr(pStart, oldstr);
    while (pFindWord != NULL) {
        //取出前后字符
        if (pFindWord == pStart) {
            pre = '\0';
        }
        else
        {
            pre = *(pFindWord - 1);
        }
        aft = *(pFindWord + strlen(oldstr));
        
        pFindChar = strchr(g_dictWords, pre);
        if (!pFindChar || pre == '\0') {
            pFindChar = strchr(g_dictWords, aft);
            if (!pFindChar || aft == '\0') {
                //printf("i am here: pPre=%c find=%s pAft=%c\n", pre, find, aft);
                iReplaceCount++;
            }
        }
        //查找位置向前移动
        pFindWord = strstr(pFindWord + strlen(oldstr), oldstr);
        pre = '\0';
        aft = '\0';
    }
    
    if (iReplaceCount > 0) {
        //step :根据统计大小，为新的字符串申请空间
        unsigned long iNewLenght = strlen(src) + (strlen(newstr) - strlen(oldstr)) * iReplaceCount;
        //printf("iReplaceCount is %d totol lenth = %lu\n", iReplaceCount, iNewLenght);
        newString = (char *)calloc(iNewLenght, 1);
        newStringTmp = newString;
        
        //step :根据原始字符串，填充新的字符串
        pStart = src;
        pFindWord = strstr(pStart, oldstr);
        while (pFindWord != NULL) {
            //取出前后字符
            if (pFindWord == pStart) {
                pre = '\0';
            }
            else
            {
                pre = *(pFindWord - 1);
            }
            aft = *(pFindWord + strlen(oldstr));
            
            pFindChar = strchr(g_dictWords, pre);
            if (!pFindChar || pre == '\0') {
                pFindChar = strchr(g_dictWords, aft);
                if (!pFindChar || aft == '\0') {
                    //拷贝找到的字符串之前的字符串
                    strncpy(newStringTmp, pStart, pFindWord - pStart);
                    //向新自负串中追加替换后的字符串
                    strcat(newStringTmp, newstr);
                    //printf("i am here: pPre=%c find=%s pAft=%c newString=%s\n", pre, pFindWord, aft, newStringTmp);
                    //开始位置向前移动
                    pStart = pFindWord + strlen(oldstr);
                    newStringTmp = newString + strlen(newString);
                }
            }
            //查找位置向前移动
            pFindWord = strstr(pFindWord + strlen(oldstr), oldstr);
            pre = '\0';
            aft = '\0';
        }
        
        //step :追加最后一部分字符串
        if (pStart != src) {
            strcat(newString, pStart);
        }
        
        //printf("last string is :%s\n", newString);
        //free(newString);
    }
    
    return newString;
}

//字符串替换，如:This is a good news.==>is -> are ==> Thare are a good news.
char *zmStringReplace(char *src, char *oldstr, char *newstr)
{
    int iReplaceCount = 0;
    char *pStart = src;
    
    char *newString = src;
    char *newStringTmp = NULL;
    //step :首先统计要替换的字符串数量
    char *pFindWord = strstr(pStart, oldstr);
    while (pFindWord != NULL) {
        iReplaceCount++;
        //查找位置向前移动
        pFindWord = strstr(pFindWord + strlen(oldstr), oldstr);
        
    }
    
    if (iReplaceCount > 0) {
        //step :根据统计大小，为新的字符串申请空间
        unsigned long iNewLenght = strlen(src) + (strlen(newstr) - strlen(oldstr)) * iReplaceCount;
        //printf("iReplaceCount is %d totol lenth = %lu\n", iReplaceCount, iNewLenght);
        newString = (char *)calloc(iNewLenght, 1);
        newStringTmp = newString;
        
        //step :根据原始字符串，填充新的字符串
        pStart = src;
        pFindWord = strstr(pStart, oldstr);
        while (pFindWord != NULL) {
            //拷贝找到的字符串之前的字符串
            strncpy(newStringTmp, pStart, pFindWord - pStart);
            //向新自负串中追加替换后的字符串
            strcat(newStringTmp, newstr);
            //printf("i am here: pPre=%c find=%s pAft=%c newString=%s\n", pre, pFindWord, aft, newStringTmp);
            //开始位置向前移动
            pStart = pFindWord + strlen(oldstr);
            newStringTmp = newString + strlen(newString);
            
            //查找位置向前移动
            pFindWord = strstr(pFindWord + strlen(oldstr), oldstr);
        }
        
        //step :追加最后一部分字符串
        if (pStart != src) {
            strcat(newString, pStart);
        }
        
        //printf("last string is :%s\n", newString);
        //free(newString);
    }
    
    return newString;
}
