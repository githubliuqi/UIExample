package com.excelsecu.shelldec;


import android.content.Context;
import android.content.pm.ApplicationInfo;

public class Dec {
	private static String DEFAULT_LIB_NAME = "ShellDec";
	private static Dec mInstance = null;
	private static Context mContext = null;
	
	public static Dec getInstance(Context context) {
		if (mInstance == null) {
			synchronized (Dec.class) {
				if (mInstance == null) {
					System.loadLibrary(DEFAULT_LIB_NAME);
					mInstance = new Dec(context);
				}
			}
		}
		
		return mInstance;
	}
	
	private Dec(Context context) {
		mContext =context;
	}
	
	public  native void verify(Object context);
	
	public  byte[] dec(final byte[] pbEncData) {
		if (isDebugable()) {
			return null;
		}
		byte[] pbData = null;
		if (null != pbEncData) {
			int[] len = new int[]{pbEncData.length+0x10};
			byte[] pbDataTmp = new byte[len[0]];
			if (0x00 == dec(pbEncData, pbEncData.length, pbDataTmp, len)) {
				pbData = new byte[len[0]];
				System.arraycopy(pbDataTmp, 0, pbData, 0, len[0]);
			}
		}
		return pbData;
	}

	private boolean isDebugable() {
		try {
			ApplicationInfo info = mContext.getApplicationInfo();
			return 0x00 != (info.flags & ApplicationInfo.FLAG_DEBUGGABLE);
		} catch (Exception e) {
			
		}
		return false;
	}
	private static native int dec(final byte[] pbEncData, int encDataLen, byte[] pbData, int[] dataLen);
}
