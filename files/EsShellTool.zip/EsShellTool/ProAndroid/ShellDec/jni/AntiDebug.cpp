#include <jni.h>
#include <Android/log.h>
#include <sys/ptrace.h>
#include <string>
#include <unistd.h>
#include <stdlib.h>
#include "AntiDebug.h"
#include "global.h"
#include "verify.h"

static void AntiDebug()
{
	ptrace(PTRACE_TRACEME, 0, 0, 0);
}
#define MAX_CLASS_DEC_METHOD_NUM 0x02
//static const char* gs_szDecClassName = "com/excelsecu/shelldec/Dec";
//static JNINativeMethod gs_DecMethods[] =
//{
//		{"dec", "([BI[B[I)I", (void*)dec},
//};

enum EnRegisterClassMethodParams
{
	com_excelsecu_shelldec_Dec = 0, // com/excelsecu/shelldec/Dec
	dec_string, // dec
	__BI_B_I_I, // ([BI[B[I)I
	verify_string, // verify
	_L_java_lang_Object_V, // ()V
	MAX_REGITSTER_CLASS_METHOD_PARAMS,
};

static BlkClassMethodParams gs_pBlkRegisterClassMethodParams[] =
{
		{com_excelsecu_shelldec_Dec, 32, {0xCE,0xBB,0x74,0x3F,0x25,0xEC,0x6F,0xEB,0x7C,0xD1,0x51,0x62,0x00,0x24,0x79,0xF6,0xEF,0x66,0x52,0x2E,0xB8,0xB2,0x0D,0xE4,0xEC,0x83,0x77,0x8E,0xF8,0x76,0x8F,0xA7}},
		{dec_string, 8, {0xD2,0xD8,0x21,0x66,0x42,0x1F,0xB0,0x40}},
		{__BI_B_I_I, 16, {0x64,0x36,0xA9,0x5A,0xA9,0xDC,0x59,0x7C,0x69,0x0E,0xFA,0xC6,0xC1,0x53,0xCC,0x25}},
		{verify_string, 8, {0x32,0xAB,0xF8,0x27,0x60,0x70,0xE5,0xC9}},
		{_L_java_lang_Object_V, 24, {0x94,0x1E,0x91,0x9F,0x47,0xD8,0x83,0x64,0xD2,0xA8,0x6C,0x40,0x42,0xD5,0x8C,0x57,0xB2,0xF4,0x7B,0xCA,0x67,0x60,0xF6,0x72,}},
};

int getString(JNIEnv *env, int nID, BlkClassMethodParams* pBlkClassMethodParams, int count, char* szData)
{
	int i = 0x00;
	int ret = 0x00;
	int  nLen = MAX_ENC_DATA_LEN;

	for (i = 0x00; i < count; i++)
	{
		if (nID == pBlkClassMethodParams[i].m_nID)
		{
			nLen = MAX_ENC_DATA_LEN;
			ret = EsDec(pBlkClassMethodParams[i].m_pu1EncMsg, (u4)pBlkClassMethodParams[i].m_nDataLen, (u1*)szData, (u4*)&nLen);
			LOGI("getString EsDec ret:%d nLen:%d", ret, nLen);
			if (0x00 == ret) {
				szData[nLen] = 0x00;
				LOGI("getString:%s", szData);
				return 0x00;
			}
			break;
		}
	}
End:
	return ret;
}


int EsRegisterNatives(JNIEnv* env)
{
	int ret = JNI_OK;
	jclass cls = NULL;
	char		szClass[MAX_ENC_DATA_LEN] = {0x00};
	char		szName[MAX_CLASS_DEC_METHOD_NUM][MAX_ENC_DATA_LEN];
	char		szSinature[MAX_CLASS_DEC_METHOD_NUM][MAX_ENC_DATA_LEN];
	JNINativeMethod pJNINativeMethod[MAX_CLASS_DEC_METHOD_NUM] = {0x00};
	int nIndex = 0x00;
	int	nCount = sizeof(gs_pBlkRegisterClassMethodParams)/sizeof(gs_pBlkRegisterClassMethodParams[0x00]);

	LOGI("EsRegisterNatives enters");
	getString(env, com_excelsecu_shelldec_Dec, gs_pBlkRegisterClassMethodParams, nCount, szClass);
	LOGI("EsRegisterNatives getString szClass=%s", szClass);
	cls = env->FindClass(szClass);
	LOGI("EsRegisterNatives cls:%p", cls);
	if (NULL == cls) {
		ret = JNI_ERR;
		goto end;
	}

	getString(env, dec_string, gs_pBlkRegisterClassMethodParams, nCount, szName[nIndex]);
	getString(env, __BI_B_I_I, gs_pBlkRegisterClassMethodParams, nCount, szSinature[nIndex]);
	pJNINativeMethod[nIndex].name = szName[nIndex];
	pJNINativeMethod[nIndex].signature = szSinature[nIndex];
	pJNINativeMethod[nIndex].fnPtr = (void*)dec;

	nIndex++;

	getString(env, verify_string, gs_pBlkRegisterClassMethodParams, nCount, szName[nIndex]);
	getString(env, _L_java_lang_Object_V, gs_pBlkRegisterClassMethodParams, nCount, szSinature[nIndex]);
	pJNINativeMethod[nIndex].name = szName[nIndex];
	pJNINativeMethod[nIndex].signature = szSinature[nIndex];
	pJNINativeMethod[nIndex].fnPtr = (void*)verify;
	nIndex++;
	ret = env->RegisterNatives(cls, pJNINativeMethod, nIndex);
end:
	LOGI("EsRegisterNatives leaves ret = %d", ret);
	return ret;
}


jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
	LOGI("JNI_OnLoad enters");
	//AntiDebug();

	JNIEnv* env;
	if (JNI_OK != vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6))
	{
		return JNI_ERR;
	}

	if (JNI_OK != EsRegisterNatives(env)) {
		return JNI_ERR;
	}

	return JNI_VERSION_1_6;
}

void be_attached_check()
{
#ifndef _ATTACH_CHECK
	return ;
#endif
	try
	{
		const int bufsize = 1024;
		char filename[bufsize];
		char line[bufsize];
		int pid = getpid();
		sprintf(filename, "/proc/%d/status", pid);
		FILE* fd = fopen(filename, "r");
		if (fd != NULL)
		{
			while (fgets(line, bufsize, fd))
			{
				if (strncmp(line, "TracerPid", 9) == 0)
				{
					int statue = atoi(&line[10]);
					LOGD("%s", line);
					if (statue != 0)
					{
						LOGD("be attached !! kill %d", pid);
						fclose(fd);
						int ret = kill(pid, SIGKILL);
						LOGD("kill ret =  %d", ret);
					}
					break;
				}
			}
			fclose(fd);
		} else
		{
			LOGD("open %s fail...", filename);
		}
	} catch (...)
	{

	}

}



