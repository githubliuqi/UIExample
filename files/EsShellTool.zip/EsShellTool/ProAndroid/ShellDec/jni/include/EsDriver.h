/*
 * EsDriver.h
 *
 *  Created on: 2014-1-16
 *      Author: zzz
 */

#ifndef _ESDRIVER_H_
#define _ESDRIVER_H_

#include "OperateKeyDEF.h"

#ifdef __cplusplus
extern "C"
{
#endif

// ��ʵ�֣�ֱ�ӷ��س���������ÿ�εײ㶼Ҫ���ָ���Ƿ�ΪNULL
u4 EmptyTransmit(const u1 *pu1Send, u4 u4SendLen, u1 *pu1Recv,
		u4 *pu4RecvLen);

u4 AudioTransmit(const u1 *pu1Send, u4 u4SendLen, u1 *pu1Recv,
		u4 *pu4RecvLen);

u4 UsbTransmit(const u1 *pu1Send, u4 u4SendLen, u1 *pu1Recv,
		u4 *pu4RecvLen);

u4 BluetoothTransmit(const u1 *pu1Send, u4 u4SendLen, u1 *pu1Recv, u4 *pu4RecvLen);

u4 BluetoothInitiativeTransmit(const u1 *pu1Send, u4 u4SendLen, u1 *pu1Recv, u4 *pu4RecvLen);

#ifdef __cplusplus
}
#endif

#endif /* ESDRIVER_H_ */
