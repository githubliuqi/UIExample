/*
 * verify.h
 *
 *  Created on: 2016年11月9日
 *      Author: win7_32
 */

#ifndef VERIFY_H_
#define VERIFY_H_


#include <jni.h>
#include <stddef.h>
#include "AntiDebug.h"

jint verifyCert(JNIEnv *env, jobject context);
jint verifyDebug(JNIEnv *env, jobject context);
//jint verifyCert(JNIEnv *env);
//jint verifyDebug(JNIEnv *env);

#endif /* VERIFY_H_ */
