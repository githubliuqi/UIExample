#ifndef _ANTI_DEBUG_H_
#define _ANTI_DEBUG_H_
#include <jni.h>
#include <android/log.h>

#ifdef _PRINT_LOG_
#define LOG_TAG "Test"
#define LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)
#define LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define LOGW(...)  __android_log_print(ANDROID_LOG_WARN,LOG_TAG,__VA_ARGS__)
#define LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)
#define LOGF(...)  __android_log_print(ANDROID_LOG_FATAL,LOG_TAG,__VA_ARGS__)
#else
#define LOGD(...)
#define LOGI(...)
#define LOGW(...)
#define LOGE(...)
#define LOGF(...)
#endif

typedef struct BlkClassMethodParamsTag
{
	int m_nID;
	int m_nDataLen;
	unsigned char m_pu1EncMsg[0x100];
}BlkClassMethodParams;

#define MAX_ENC_DATA_LEN 0x100

#ifdef __cplusplus
extern "C"{
#endif

jint dec(JNIEnv* env, jobject thiz,
		jbyteArray pu1EncData, jint u4EncDataLen, jbyteArray pu1Data, jintArray pu4DataLen);
void verify(JNIEnv* env, jobject thiz, jobject context);
void be_attached_check();
int getString(JNIEnv *env, int nID, BlkClassMethodParams* pBlkClassMethodParams, int count, char* szData);

#ifdef __cplusplus
}
#endif

#endif
