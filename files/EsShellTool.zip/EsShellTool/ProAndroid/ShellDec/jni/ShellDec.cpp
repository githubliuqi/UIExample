#include <jni.h>
#include <android/log.h>
#include "global.h"
#include "AntiDebug.h"
#include "Verify.h"


#define FUNS(s) Java_com_excelsecu_shelldec_Dec_##s

#ifdef __cplusplus
extern "C"
{
#endif

void _init(void){}

jint dec(JNIEnv* env, jobject thiz,
		jbyteArray pu1EncData, jint u4EncDataLen, jbyteArray pu1Data, jintArray pu4DataLen)
//jint FUNS(dec)(JNIEnv* env, jobject thiz,
//		jbyteArray pu1EncData, jint u4EncDataLen, jbyteArray pu1Data, jintArray pu4DataLen)
{
	be_attached_check();
	if (NULL == pu1EncData || NULL == pu1Data || NULL == pu4DataLen)
	{
		return ERROR_COMMON_INVALID_PARAM;
	}

	jint nRet;
	jbyte* pbEncData = (env)->GetByteArrayElements(pu1EncData, 0);
	jbyte* pbData = (env)->GetByteArrayElements(pu1Data, 0);
	jint* pnDataLen = (env)->GetIntArrayElements(pu4DataLen, 0);
	nRet = EsDec((const u1*)pbEncData, (u4)u4EncDataLen, (u1*)pbData, (u4*)pnDataLen);
	(env)->ReleaseByteArrayElements(pu1EncData, pbEncData, 0);
	(env)->ReleaseByteArrayElements(pu1Data, pbData, 0);
	(env)->ReleaseIntArrayElements(pu4DataLen, pnDataLen, 0);

	return nRet;
}

void killProgress()
{
   LOGI("killProgress");
   kill(getpid(),SIGKILL);
}

//void FUNS(verify)(JNIEnv* env, jobject thiz, jobject context)
void verify(JNIEnv* env, jobject thiz, jobject context)
{
	LOGI("FUNS(verify) enter");
	LOGI("FUNS(verify) jcontext = %p",context);
     if (NULL == context)
     {
        return ;
     }
	jint verifyOk = verifyCert(env, context);
	if (JNI_OK != verifyOk) {
		killProgress();
	}
	verifyOk = verifyDebug(env, context);
	if (JNI_OK != verifyOk) {
		killProgress();
	}
}


#ifdef __cplusplus
}
#endif
