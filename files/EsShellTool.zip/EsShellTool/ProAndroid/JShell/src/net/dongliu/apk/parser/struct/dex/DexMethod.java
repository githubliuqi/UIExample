package net.dongliu.apk.parser.struct.dex;

public class DexMethod {

	public String clazz; // 所属类
	public String name; // 函数名字
	public DexProto proto; //函数原型
}
