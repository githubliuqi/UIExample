package net.dongliu.apk.parser.bean;

/**
 * @author dongliu
 */
public enum ApkSignStatus {
    notSigned, incorrect, signed
}
